/** @format */
'use client';

function Error({ error }) {
  return (
    <main className="error">
      <h1>An Error occurred!</h1>
      <p>Failed to create meal.</p>
    </main>
  );
}

export default Error;
